# Data dictionary

## `studies.csv`
One row per unique primary study.
- `pmcid`, `pmid`, `doi`: stable identifiers.
- `title`, `publication_year`, `journal`: bibliographic metadata.
- `support_class`, `enzyme_class`, `attachment_chemistry`: manually adjudicated categories.
- `screening_decision`, `exclusion_reason`: final human decision and reason.
- `fulltext_sha256`: checksum of retrieved source XML.
- `reviewer_id`, `adjudication_date`: audit trail.

## `observations.csv`
One row per accepted source sentence/outcome.
- `pmcid`: parent study.
- `outcome_type`: e.g. reuse_retention, immobilisation_yield, free_enzyme_relative_activity, storage_stability, enzyme_loading.
- `cycle_count`: reuse cycle count, if applicable.
- `retained_activity_pct`: percentage retained, if applicable.
- `storage_days`: duration for storage stability, if applicable.
- `value`, `unit`: other numeric outcomes.
- `verbatim_sentence`: exact source sentence.
- `source_location`: XML section/paragraph or page/table location.
- `extraction_rule_version`: software version.
- `human_verified`: true only after independent source check.
- `reviewer_note`: rationale/correction.

## `screening_decisions.csv`
One row per retrieved unique record, including every excluded record. Preserve sequential primary exclusion reason and final reviewer decision.

## `validation_sample.csv`
A prespecified random sample of extraction candidates with predicted value, reviewer truth, correct/incorrect flag, reviewer identity and adjudication notes. Keep validation rounds disjoint.
