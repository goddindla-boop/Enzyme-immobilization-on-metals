# Algorithm and methodological specification

## A. Corpus construction
1. Define three concept blocks: immobilisation, enzyme/biocatalyst, and one support-material class.
2. Search Europe PMC title/abstract fields and restrict to open-access records.
3. Retrieve all pages for every support query; store exact query, timestamp, hit count and returned identifiers.
4. Deduplicate by PMCID, then PMID, then DOI. Preserve all query memberships.
5. Download JATS full-text XML for records with a PMCID and save a SHA-256 checksum.

## B. Sequential screening
Apply in this order, recording exactly one primary reason for each exclusion:
1. Full text unavailable/unparseable.
2. Review or non-primary article.
3. Fewer than five immobilisation-topic mentions.
4. Fewer than three metal-support mentions.
5. Fewer than three enzyme mentions.
6. No quantitative reuse outcome extractable by the conservative rule.

The automatic screen is only a triage mechanism. Human reviewers must verify article type, topic relevance, support identity, enzyme identity and quantitative outcome. A term-frequency classifier must not be treated as definitive classification.

## C. Sentence-level extraction
For each full text:
1. Remove references and back matter.
2. Segment text into candidate sentences.
3. Identify cycle-count expressions (numeric and supported number words).
4. Identify percentage expressions.
5. Reject sentences with ambiguous multiple cycle counts or percentages.
6. Reject percentage contexts likely to refer to concentration, uncertainty, or competing metrics.
7. Convert “decreased by x%” to retained activity `100 - x`; interpret “declined to x%” as retained activity `x`.
8. Preserve the exact sentence and source PMCID with every candidate value.
9. Human reviewer marks each candidate accepted/rejected and records reason.
10. For each study, select its highest reported cycle count; if multiple values occur at that cycle, use the median and document that the median may not itself be an author-reported value.

## D. Statistical synthesis
- Report median, IQR, range, mean and SD for each outcome.
- Use one study-level reuse value per study for study-level associations.
- Use Spearman rank correlation for cycle count versus retained activity.
- Use OLS as a descriptive companion, reporting slope, 95% CI, p-value and R-squared.
- Use Kruskal-Wallis for comparisons across more than two groups and Mann-Whitney U for two groups.
- Use exact binomial tests for prespecified terminal-digit and multiple-of-five hypotheses.
- Apply Holm-Bonferroni correction across the complete inferential test family declared before analysis.
- Do not fit a variance-weighted random-effects model unless compatible within-study variances/effect sizes are available.

## E. Pseudocode

```text
records = []
for support_class in support_classes:
    q = immobilisation_block AND enzyme_block AND support_block[support_class] AND open_access
    records += EuropePMC.search_all_pages(q)

records = deduplicate(records, keys=[PMCID, PMID, DOI])
for record in records:
    xml = EuropePMC.fetch_full_text(record.PMCID)
    if xml unavailable:
        decision = EXCLUDE(full_text_unavailable)
        continue
    text = normalise(xml)
    if is_review(text): EXCLUDE(review); continue
    if count(immobilisation_terms) < threshold: EXCLUDE(topic); continue
    if count(metal_support_terms) < threshold: EXCLUDE(support); continue
    if count(enzyme_terms) < threshold: EXCLUDE(enzyme); continue

    for sentence in split_sentences(text):
        cycles = detect_cycle_counts(sentence)
        percentages = detect_percentages(sentence)
        if exactly_one(cycles) and exactly_one(percentages):
            if not competing_metric_or_concentration(sentence):
                value = resolve_polarity(sentence, percentages[0])
                save_candidate(record, cycles[0], value, sentence)

human_adjudicate(all_candidates, all_screening_decisions)
study_values = choose_highest_cycle_per_study_and_median_ties()
run_descriptive_and_prespecified_tests(study_values, raw_unique_observations)
export_tables_figures_logs_and_environment()
```

## F. Important implementation caveat
The manuscript's reported screening strata and exact queries cannot be reconstructed exactly from the PDF alone. The executable code is a transparent, conservative starting implementation, not proof that the original study's pipeline has been recreated.
