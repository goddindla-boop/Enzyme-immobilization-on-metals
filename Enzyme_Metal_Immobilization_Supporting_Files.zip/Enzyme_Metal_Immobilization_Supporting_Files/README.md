# Reproducibility package
## Immobilization of Enzymes on Metal and Metal-Oxide Surfaces

This package is a **reproducibility framework** prepared from the supplied 11-page manuscript. It is not a reconstruction of the manuscript's undisclosed study-level dataset.

### Critical provenance note
The PDF reports 849 retrieved records, 155 included studies and 164 reuse observations, and says that the corpus, extraction code, query hit counts, screening decisions, supporting sentences and validation samples are released. Those underlying files were **not present in the supplied PDF**. Consequently:

- `data/studies.csv`, `data/observations.csv`, `data/screening_decisions.csv` and `data/validation_sample.csv` are empty schema templates.
- No synthetic records or invented enzyme-performance measurements are included.
- The query blocks in `config.json` are transparent, editable reconstructions from the manuscript's described support classes and topic, **not verified verbatim query strings** from the original study.
- Running the pipeline will harvest the currently available Europe PMC open-access corpus, which may differ from the manuscript's 29 September 2026 snapshot.
- Numerical results in the manuscript cannot be reproduced until the original record list, exact queries, screening decisions and extracted observations are supplied or independently recreated and audited.

### Package contents
- `src/harvest_europepmc.py`: Europe PMC search and full-text XML retrieval.
- `src/screen_extract.py`: sequential screening and conservative sentence-level reuse extraction.
- `src/analyse.py`: descriptive statistics, non-parametric tests, OLS, Wilson intervals and Holm correction.
- `src/run_pipeline.py`: sequential command-line runner.
- `config.json`: editable query blocks, screening thresholds and controlled vocabularies.
- `data/*.csv`: empty data schemas; populate only from source records and audited extraction.
- `docs/ALGORITHM.md`: algorithm and pseudocode.
- `docs/DATA_DICTIONARY.md`: field definitions.
- `docs/VALIDATION_PROTOCOL.md`: independent audit plan.
- `requirements.txt`: Python dependencies.

### Environment
Python 3.10 or later is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

### Run
From the package root:

```bash
python src/run_pipeline.py --config config.json
```

The harvest step uses the live Europe PMC REST API and therefore requires internet access. Respect Europe PMC usage policies and use a contact email in the configuration if performing large harvests.

### Reproducible run and provenance
For every run, retain:
1. retrieval date/time (UTC);
2. exact query strings and result counts;
3. Europe PMC IDs and PMCID values;
4. downloaded XML files and checksums;
5. screening decision and exclusion reason for every record;
6. extracted sentence, source PMCID and extraction rule version;
7. manually audited validation labels;
8. package version, Python version and dependency versions.

### Interpretation
The manuscript describes a systematic review with quantitative synthesis of reported point estimates, **not** a variance-weighted effect-size meta-analysis. The included studies generally do not provide compatible variances, so this package deliberately avoids a random-effects meta-analysis. Group comparisons are descriptive and observational, not causal.

Do not state that the manuscript's reported numerical results have been independently reproduced unless the complete source dataset has been populated, checked and the outputs match.
