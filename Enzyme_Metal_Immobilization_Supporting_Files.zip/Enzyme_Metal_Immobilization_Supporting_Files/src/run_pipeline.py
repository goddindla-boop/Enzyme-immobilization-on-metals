#!/usr/bin/env python3
"""Run harvest, automatic screening/extraction, and (only after manual review) analysis."""
import argparse, subprocess, sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument("--config",default="config.json")
a=p.parse_args()
root=Path(__file__).resolve().parent.parent
def run(script,*args):
    subprocess.run([sys.executable,str(root/"src"/script),*args],cwd=root,check=True)
run("harvest_europepmc.py","--config",a.config)
run("screen_extract.py","--config",a.config)
print("\nSTOP: inspect and manually adjudicate data/observations_auto.csv and screening_decisions_auto.csv.")
print("Copy only audited records to data/observations.csv before running src/analyse.py.")
