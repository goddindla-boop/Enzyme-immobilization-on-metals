#!/usr/bin/env python3
"""Descriptive synthesis and statistical tests on human-verified observations only."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.proportion import proportion_confint
import statsmodels.api as sm

def holm(pvalues):
    if not pvalues: return []
    return multipletests(pvalues, method="holm")[1].tolist()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data",default="data/observations.csv")
    ap.add_argument("--out",default="outputs")
    a=ap.parse_args()
    df=pd.read_csv(a.data)
    required={"pmcid","cycle_count","retained_activity_pct","human_verified"}
    if not required.issubset(df.columns):
        raise SystemExit(f"Required columns: {sorted(required)}")
    verified=df[df["human_verified"].astype(str).str.lower().isin(["true","1","yes"])].copy()
    if verified.empty:
        raise SystemExit("No human-verified rows. Populate observations.csv from audited source sentences first.")
    verified["cycle_count"]=pd.to_numeric(verified.cycle_count,errors="coerce")
    verified["retained_activity_pct"]=pd.to_numeric(verified.retained_activity_pct,errors="coerce")
    verified=verified.dropna(subset=["cycle_count","retained_activity_pct"])
    out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    summary=verified[["cycle_count","retained_activity_pct"]].describe(percentiles=[.25,.5,.75])
    summary.to_csv(out/"descriptive_summary.csv")
    # One value per study at the highest reported cycle count; median for tied top-cycle values.
    top=verified.groupby("pmcid").cycle_count.max().rename("max_cycle")
    x=verified.merge(top,on="pmcid")
    study=x[x.cycle_count==x.max_cycle].groupby("pmcid").agg(
        cycle_count=("cycle_count","first"),retained_activity_pct=("retained_activity_pct","median")).reset_index()
    if len(study)>=3:
        rho=stats.spearmanr(study.cycle_count,study.retained_activity_pct)
        X=sm.add_constant(study.cycle_count)
        fit=sm.OLS(study.retained_activity_pct,X).fit()
        pd.DataFrame([{"n":len(study),"spearman_rho":rho.statistic,"spearman_p":rho.pvalue,
                       "ols_intercept":fit.params.iloc[0],"ols_slope_pct_per_cycle":fit.params.iloc[1],
                       "ols_slope_p":fit.pvalues.iloc[1],"ols_r_squared":fit.rsquared,
                       "slope_ci_low":fit.conf_int().iloc[1,0],"slope_ci_high":fit.conf_int().iloc[1,1]}]).to_csv(out/"cycle_association.csv",index=False)
    # Integer-valued digit analysis, kept separate from decimal observations.
    vals=verified.retained_activity_pct.to_numpy()
    ints=np.isclose(vals,np.round(vals))
    iv=np.round(vals[ints]).astype(int)
    if len(iv):
        endings=iv%10
        count05=int(np.isin(endings,[0,5]).sum())
        ci=proportion_confint(count05,len(iv),method="wilson")
        binom=stats.binomtest(count05,len(iv),p=.2,alternative="greater")
        pd.DataFrame([{"n_integer_values":len(iv),"ending_0_or_5":count05,
          "proportion":count05/len(iv),"wilson_low":ci[0],"wilson_high":ci[1],
          "binomial_p_vs_20pct":binom.pvalue}]).to_csv(out/"terminal_digit_summary.csv",index=False)
    print(f"Analysed {len(verified)} human-verified observations from {study.shape[0]} studies.")
    print(f"Outputs written to {out}. Results are not manuscript replication unless source data are complete.")

if __name__=="__main__": main()
