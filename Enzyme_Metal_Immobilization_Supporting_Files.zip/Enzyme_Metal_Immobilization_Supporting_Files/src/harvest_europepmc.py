#!/usr/bin/env python3
"""Harvest Europe PMC open-access records and full-text XML.

The query construction is editable and is not asserted to be the exact query
used in the manuscript. Historical snapshots cannot be recreated by a live API.
"""
from __future__ import annotations
import argparse, hashlib, json, os, time
from pathlib import Path
import requests
import pandas as pd

API = "https://www.ebi.ac.uk/europepmc/webservices/rest"

def build_query(topic_terms, enzyme_terms, support_terms):
    topic = "(" + " OR ".join(f'TITLE_ABS:"{x}"' for x in topic_terms) + ")"
    enzyme = "(" + " OR ".join(f'TITLE_ABS:"{x}"' for x in enzyme_terms) + ")"
    support = "(" + " OR ".join(f'TITLE_ABS:"{x}"' for x in support_terms) + ")"
    return f"{topic} AND {enzyme} AND {support} AND OPEN_ACCESS:Y"

def search(query, page_size=100, max_records=10000):
    rows, page = [], 1
    while len(rows) < max_records:
        params = {"query": query, "format": "json", "pageSize": min(page_size, max_records-len(rows)), "page": page, "resultType": "core"}
        response = requests.get(f"{API}/search", params=params, timeout=60)
        response.raise_for_status()
        payload = response.json()
        batch = payload.get("resultList", {}).get("result", [])
        if not batch:
            break
        rows.extend(batch)
        if len(rows) >= int(payload.get("hitCount", 0)):
            break
        page += 1
        time.sleep(0.15)
    return rows

def fetch_xml(pmcid, outdir):
    clean = pmcid.replace("PMC", "")
    url = f"{API}/PMC{clean}/fullTextXML"
    response = requests.get(url, timeout=60)
    if response.status_code != 200:
        return None
    path = outdir / f"PMC{clean}.xml"
    path.write_bytes(response.content)
    return {"path": str(path), "sha256": hashlib.sha256(response.content).hexdigest(), "url": url}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--out", default="data/harvest")
    args = ap.parse_args()
    cfg = json.loads(Path(args.config).read_text(encoding="utf-8"))
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    xml_dir = out / "xml"; xml_dir.mkdir(exist_ok=True)
    query_rows, record_rows = [], []
    for support, terms in cfg["support_classes"].items():
        q = build_query(cfg["immobilization_terms"], cfg["enzyme_terms"], terms)
        results = search(q, cfg["page_size"], cfg["max_records_per_query"])
        query_rows.append({"support_class": support, "query": q, "hits_returned": len(results)})
        for rec in results:
            rec["_query_support_class"] = support
            rec["_query_string"] = q
            record_rows.append(rec)
    df = pd.DataFrame(record_rows)
    if not df.empty:
        # Deduplicate by PMID/PMCID/DOI in that order; retain source query provenance.
        df["dedup_key"] = df.get("pmcid", pd.Series(index=df.index, dtype=str)).fillna("")
        df.loc[df["dedup_key"].eq(""), "dedup_key"] = df.get("pmid", "").astype(str)
        df.loc[df["dedup_key"].eq(""), "dedup_key"] = df.get("doi", "").astype(str)
        df = df.drop_duplicates("dedup_key", keep="first")
    xml_meta = []
    for _, rec in df.iterrows() if not df.empty else []:
        pmcid = str(rec.get("pmcid", "") or "")
        if pmcid.startswith("PMC"):
            meta = fetch_xml(pmcid, xml_dir)
            if meta:
                xml_meta.append({"pmcid": pmcid, **meta})
            time.sleep(0.15)
    df.to_csv(out/"records.csv", index=False)
    pd.DataFrame(query_rows).to_csv(out/"query_log.csv", index=False)
    pd.DataFrame(xml_meta).to_csv(out/"xml_manifest.csv", index=False)
    print(f"Retrieved {len(record_rows)} query-level records; {len(df)} unique records.")
    print(f"Full-text XML downloaded: {len(xml_meta)}")
    print("IMPORTANT: this is a live harvest, not the manuscript's historical snapshot.")

if __name__ == "__main__":
    main()
