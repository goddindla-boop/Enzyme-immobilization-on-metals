#!/usr/bin/env python3
"""Sequential screening and conservative sentence-level operational reuse extraction."""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
from lxml import etree
import pandas as pd

PERCENT = re.compile(r'(?P<pct>\d+(?:\.\d+)?)\s*(?:%|percent)', re.I)
CYCLE = re.compile(r'(?:after|at|up to|following|through|cycle\s*(?:no\.?|number)?|the)\s*(?P<n>\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty|fifty)(?:st|nd|rd|th)?\s*(?:reuse\s*)?cycles?', re.I)
WORDNUM = {"one":1,"two":2,"three":3,"four":4,"five":5,"six":6,"seven":7,"eight":8,"nine":9,"ten":10,"eleven":11,"twelve":12,"fifteen":15,"twenty":20,"thirty":30,"fifty":50}
NEG_BY = re.compile(r'(?:decreased|reduced|declined|lost|dropped|fell)\s+by\s+', re.I)
BAD_CONTEXT = re.compile(r'(?:±|standard deviation|confidence interval|concentration|w/v|v/v|mg/ml|mg mL|mol/l)', re.I)

def xml_to_text(path):
    root = etree.parse(str(path))
    for node in root.xpath('//ref-list|//ack|//fn-group|//author-notes'):
        node.getparent().remove(node)
    return " ".join(" ".join(root.getroot().itertext()).split())

def sentences(text):
    # Conservative split; avoids claiming full linguistic sentence segmentation.
    return re.split(r'(?<=[.!?])\s+(?=[A-Z0-9“"])', text)

def first_count(sentence):
    m = CYCLE.search(sentence)
    if not m: return None
    n = m.group("n").lower()
    return WORDNUM.get(n, int(n) if n.isdigit() else None)

def extract_reuse(sentence):
    """Return one unambiguous (cycle, retained_activity_percent) pairing or None."""
    if BAD_CONTEXT.search(sentence):
        return None
    cm = list(CYCLE.finditer(sentence))
    pm = list(PERCENT.finditer(sentence))
    if len(cm) != 1 or len(pm) != 1:
        return None
    cycle = first_count(sentence)
    if cycle is None or cycle < 1 or cycle > 500:
        return None
    pct = float(pm[0].group("pct"))
    if not (0 <= pct <= 100):
        return None
    # Convert loss-by statements to retained activity; level constructions are retained as stated.
    prefix = sentence[max(0, pm[0].start()-70):pm[0].start()]
    if NEG_BY.search(prefix):
        pct = 100.0 - pct
    return cycle, pct

def term_count(text, terms):
    low = text.lower()
    return sum(len(re.findall(re.escape(t.lower()), low)) for t in terms)

def classify(text, vocab):
    low = text.lower()
    counts = {k: sum(len(re.findall(re.escape(t.lower()), low)) for t in terms) for k,terms in vocab.items()}
    return max(counts, key=counts.get) if counts and max(counts.values()) > 0 else "unknown"

def screen(text, cfg):
    # Sequential order follows the manuscript's described screening logic.
    if not text.strip(): return False, "full_text_unavailable_or_unparseable"
    if re.search(r'\b(review|systematic review|meta-analysis)\b', text[:2500], re.I):
        return False, "review_or_non_primary_flag_manual_confirmation"
    if term_count(text, cfg["immobilization_terms"]) < cfg["minimum_immobilization_mentions"]:
        return False, "insufficient_immobilization_mentions"
    support_total = sum(term_count(text, terms) for terms in cfg["support_classes"].values())
    if support_total < cfg["minimum_support_mentions"]:
        return False, "insufficient_metal_support_mentions"
    if term_count(text, cfg["enzyme_terms"]) < cfg["minimum_enzyme_mentions"]:
        return False, "insufficient_enzyme_mentions"
    if not any(extract_reuse(s) for s in sentences(text)):
        return False, "no_rule_matched_reuse_outcome"
    return True, "included_automatic_screen_requires_human_review"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--config",default="config.json")
    ap.add_argument("--harvest",default="data/harvest")
    ap.add_argument("--out",default="data")
    a=ap.parse_args()
    cfg=json.loads(Path(a.config).read_text(encoding="utf-8"))
    harvest=Path(a.harvest); out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    records=pd.read_csv(harvest/"records.csv")
    xml_map={}
    manifest=harvest/"xml_manifest.csv"
    if manifest.exists():
        for _,r in pd.read_csv(manifest).iterrows(): xml_map[str(r.pmcid)]=r.path
    decisions=[]; observations=[]
    for _,rec in records.iterrows():
        pmcid=str(rec.get("pmcid","") or "")
        path=xml_map.get(pmcid)
        text=xml_to_text(path) if path and Path(path).exists() else ""
        include,reason=screen(text,cfg)
        support=classify(text,cfg["support_classes"]) if text else "unknown"
        chemistry=classify(text,cfg["attachment_chemistries"]) if text else "unknown"
        enzyme=classify(text,{"enzyme":cfg["enzyme_terms"]}) if text else "unknown"
        decisions.append({"pmcid":pmcid,"title":rec.get("title",""),"included_automatic":include,
                          "screening_decision":"REVIEW_REQUIRED" if include else "EXCLUDE_PENDING_REVIEW",
                          "exclusion_reason":reason,"support_class_auto":support,
                          "attachment_chemistry_auto":chemistry,"enzyme_auto":enzyme})
        if include:
            for sent in sentences(text):
                result=extract_reuse(sent)
                if result:
                    cycles,retention=result
                    observations.append({"pmcid":pmcid,"cycle_count":cycles,"retained_activity_pct":retention,
                        "verbatim_sentence":sent,"extraction_rule_version":"0.1.0",
                        "human_verified":False,"source_file":path})
    pd.DataFrame(decisions).to_csv(out/"screening_decisions_auto.csv",index=False)
    pd.DataFrame(observations).to_csv(out/"observations_auto.csv",index=False)
    print(f"Screened {len(decisions)} records; {len(observations)} candidate observations.")
    print("All automated decisions are provisional and require human screening/audit.")

if __name__=="__main__": main()
